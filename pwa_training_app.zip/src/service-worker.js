self.addEventListener('install', (evt) => {
  self.skipWaiting()
})

self.addEventListener('activate', (evt) => {
  console.log('SW activated')
})

self.addEventListener('fetch', (evt) => {
  // basic offline: falling back to network. Expand as needed.
})
