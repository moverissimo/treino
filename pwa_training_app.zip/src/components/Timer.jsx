import { useState, useEffect } from 'react'

export default function Timer({ seconds = 30 }) {
  const [counter, setCounter] = useState(seconds)
  const [running, setRunning] = useState(false)

  useEffect(() => {
    let interval = null
    if (running && counter > 0) {
      interval = setInterval(() => setCounter(c => Math.max(0, c-1)), 1000)
    }
    return () => clearInterval(interval)
  }, [running, counter])

  useEffect(() => {
    setCounter(seconds)
    setRunning(false)
  }, [seconds])

  function toggle() {
    setRunning(r => !r)
  }

  function reset() {
    setCounter(seconds)
    setRunning(false)
  }

  return (
    <div className="text-center">
      <p className="text-lg font-bold">{counter}s</p>
      <div className="flex gap-2 justify-center mt-2">
        <button onClick={toggle} className="px-3 py-1 bg-gray-200 rounded"> {running ? 'Pause' : 'Start'} </button>
        <button onClick={reset} className="px-3 py-1 bg-gray-200 rounded">Reset</button>
      </div>
    </div>
  )
}
