import { useState } from 'react'
import Home from './pages/Home'
import Treino from './pages/Treino'

export default function App() {
  const [page, setPage] = useState('home')
  const [treinoSelecionado, setTreinoSelecionado] = useState(null)

  function abrirTreino(treino) {
    setTreinoSelecionado(treino)
    setPage('treino')
  }

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      {page === 'home' && <Home onSelectTreino={abrirTreino} />}
      {page === 'treino' && (
        <Treino treino={treinoSelecionado} onBack={() => setPage('home')} />
      )}
    </div>
  )
}
