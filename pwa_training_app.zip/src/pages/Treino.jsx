import { useState } from 'react'
import Timer from '../components/Timer'

export default function Treino({ treino, onBack }) {
  const [index, setIndex] = useState(0)
  const ex = treino.exercicios[index]

  function proximo() {
    if (index < treino.exercicios.length - 1) {
      setIndex(index + 1)
    } else {
      alert('Treino concluído! 🟢')
      onBack()
    }
  }

  return (
    <div>
      <button className="mb-4 text-blue-600" onClick={onBack}>⬅ Voltar</button>

      <h1 className="text-2xl font-bold mb-2">{treino.treino}</h1>

      <div className="bg-white p-4 rounded-xl shadow">
        <h2 className="text-xl font-semibold">{ex.nome}</h2>
        <p className="text-gray-600">Séries: {ex.series || '—'}</p>
        <p className="mt-2">{ex.instrucoes}</p>

        <div className="mt-4">
          <Timer seconds={30} />
        </div>

        <button
          onClick={proximo}
          className="mt-4 w-full bg-blue-600 text-white py-2 rounded-xl"
        >
          Próximo exercício →
        </button>
      </div>
    </div>
  )
}
