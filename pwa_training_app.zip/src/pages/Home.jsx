import treinos from '../data/treinos.json'

export default function Home({ onSelectTreino }) {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Seus Treinos</h1>

      <div className="grid gap-4">
        {treinos.map((t, i) => (
          <button
            key={i}
            onClick={() => onSelectTreino(t)}
            className="p-4 bg-white rounded-xl shadow hover:bg-blue-50 text-left"
          >
            <p className="text-xl font-semibold">{t.treino}</p>
            <p className="text-gray-600">{t.exercicios.length} exercícios</p>
          </button>
        ))}
      </div>
    </div>
  )
}
